# settings

1. yarn install

2. yarn run dev
