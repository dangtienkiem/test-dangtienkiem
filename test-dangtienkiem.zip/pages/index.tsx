import Home from "../HomePage";

export default Home;