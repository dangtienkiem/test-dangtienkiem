import styled from 'styled-components';

export const BannerStyled = styled.div`
  padding-top: 60px;
  height: 428px;
`;
