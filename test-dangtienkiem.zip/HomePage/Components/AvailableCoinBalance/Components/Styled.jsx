import styled from 'styled-components';

export const GameFeaturesStyled = styled.div`
  background-repeat: no-repeat;
  background-size: cover;
`;
